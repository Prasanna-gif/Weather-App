# WeaZard-App
A simple weather forecast web app, currently under development ✨

## Wanna test it ?

You can test it at [Weazard App](https://weazard-app.netlify.app)
